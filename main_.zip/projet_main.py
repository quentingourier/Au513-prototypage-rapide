import sys, os, requests, json, re, urllib.parse,pickle
from PyQt5.QtWidgets import QApplication,  QTabWidget,QWidget, QHBoxLayout, QVBoxLayout, QLabel, QLineEdit, QPushButton,QFrame,QListWidget,QMainWindow,QFormLayout,QCheckBox
from PyQt5.QtGui import QPixmap,QIcon
from PyQt5.QtCore import QUrl,Qt
import sqlite3
from PyQt5.QtWebEngineWidgets import QWebEngineView
from tkinter import *
from PIL import Image, ImageTk
import cv2 as cv
import time, pickle
import pytesseract
from pytesseract import Output
from matplotlib import pyplot as plt
from datetime import date
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd
import numpy as np



def connexion_window():
    global etat_utilisateur
    global etat_create

    def verify_account():
        global etat_utilisateur
        global etat_create
        global utilisateur
        username = username_entry.text()
        password = password_entry.text()

        if username != "" and password != "":
        # Connexion à la base de données
            conn = sqlite3.connect('files/database.db')

            # Création du curseur
            cursor = conn.cursor()

            # Récupération de l'utilisateur avec le username spécifié
            cursor.execute("SELECT * FROM users WHERE username=?", (username,))

            # Récupération du résultat de la requête
            user = cursor.fetchone()

            # Vérification de l'existence de l'utilisateur et du mot de passe
            if user is not None and user[4] == password:
                # Si l'utilisateur existe et que le mot de passe correspond, on affiche un message
                result_label.setText("Connexion réussie !\n")
                etat_create = username_entry.text()
                username_entry.clear()
                password_entry.clear()
                window.close()
                etat_utilisateur = 3
                #user_window()
                 
                #user_window()
            else:
                # Si l'utilisateur n'existe pas ou que le mot de passe ne correspond pas, on affiche un message d'erreur
                result_label.setText("Informations incorrectes !\n")
                password_entry.clear()  

            # Fermeture de la connexion
            conn.close()
    
    def create_account():
      global etat_utilisateur
      window.close()
      etat_utilisateur = 2

    
    app = QApplication(sys.argv)
    # Création de l'objet QWidget
    window = QWidget()
    layout = QHBoxLayout()

    # Création des widgets
    image_label = QLabel()
    image_label.setPixmap(QPixmap('images/logo_QYL.png'))

    title_layout = QLabel("\n  Espace Connexion \n")
    title_layout.setStyleSheet("font-family: MS Gothic;font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

    username_label = QLabel("\nNom d'utilisateur :")
    username_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;font-weight: bold;")
    username_entry = QLineEdit()
    if etat_create !=  "":
        username_entry.setText(etat_create)
        etat_create == ""
    username_entry.setStyleSheet("font-size: 22pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    username_entry.setFixedWidth(400)

    password_label = QLabel("\nMot de passe :")
    password_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;font-weight: bold;")
    password_entry = QLineEdit()
    password_entry.setEchoMode(QLineEdit.Password)
    password_entry.setStyleSheet("font-size: 22pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")

    result_label =QLabel("\n")
    result_label.setStyleSheet("font-size: 18pt;color: black;")

    empty_label = QLabel("\n")
    empty_label.setStyleSheet("font-size: 18pt")

    empty2_label = QLabel("\n")
    empty2_label.setStyleSheet("font-size: 18pt")

    empty3_label = QLabel("  ")
    empty3_label.setStyleSheet("font-size: 18pt")

    login_button = QPushButton("Se connecter")
    login_button.clicked.connect(verify_account)
    login_button.setStyleSheet("font-size: 20pt; font-family: MS Gothic; color: blue;background-color: white;border-radius: 5px;")
    login_button.setFixedWidth(280)

    create_account_button = QPushButton("Créer un compte")
    create_account_button .clicked.connect(create_account)
    create_account_button.setStyleSheet("font-size: 20pt; font-family: MS Gothic; color: blue;background-color: white;border-radius: 5px;")
    create_account_button.setFixedWidth(280)

    frame = QFrame()
    frame.setFrameShape(QFrame.VLine)
    frame.setStyleSheet("color: white;")


    # Création du layout de gauche (pour l'illustration)
    left_layout = QHBoxLayout()
    left_layout.addWidget(image_label)
    left_layout.addWidget(frame)
    left_layout.addWidget(empty3_label)

    # Création du layout de droite (pour l'espace de connexion)
    right_layout = QVBoxLayout()
    right_layout.addWidget(title_layout)
    right_layout.addWidget(username_label)
    right_layout.addWidget(username_entry)
    right_layout.addWidget(password_label)
    right_layout.addWidget(password_entry)
    right_layout.addWidget(result_label)
    right_layout.addWidget(empty_label)
    right_layout.addWidget(login_button, 0, Qt.AlignHCenter)
    right_layout.addWidget(create_account_button, 0, Qt.AlignHCenter)
    right_layout.addWidget(empty2_label)
    right_layout.addStretch()

    # Ajout des layouts de gauche et de droite au layout principal
    layout.addLayout(left_layout)
    layout.addLayout(right_layout)

    # Affectation du layout principal à la fenêtre
    
    window.setLayout(layout)
    window.setStyleSheet("background-color: rgb(3, 82, 181);")
    # Affichage de la fenêtre
    window.show()

    
    #window.show()
    app.exec_()
    app.exit()
    




def user_window():

    global etat_utilisateur 
    global etat_create

    def disconnect_fct():
        global etat_utilisateur 
        etat_utilisateur = 1
        window.close()

    def get_channel_name(url):
        # Extract the video ID from the URL
        video_id = re.search(r"v=([^&]+)", url).group(1)

        response = requests.get(
            "https://www.googleapis.com/youtube/v3/videos",
            params={
            "key": api_key,
            "part": "snippet",
            "id": video_id
            }
        )

        response_json = response.json()
        if response_json["items"]:
            # video_topic = response_json["items"][0]["snippet"]["description"]
            channel_name = response_json["items"][0]["snippet"]["channelTitle"]
        else:
            # video_topic = "Video not found"
            channel_name = "Channel not found"

        return channel_name

    def get_video_title(url):
        # Send a GET request to the URL
        response = requests.get(url)
        # Parse the HTML of the page
        soup = BeautifulSoup(response.text, 'html.parser')
        # Find the <title> element and extract the text from it
        title = soup.find('title').text

        channel_name = get_channel_name(url)

        return title, channel_name

    def extract_search_query(url, query_flag):
        # Parse the URL into its component parts
        parsed_url = urllib.parse.urlparse(url)
        # Extract the query string
        query = parsed_url.query
        # Parse the query string into a dictionary
        query_dict = urllib.parse.parse_qs(query)
        # Extract the value of the 'q' key, which represents the search query
        search_query = query_dict.get(query_flag, [''])[0]
    
        return search_query

    def update_history(url, history_list):
        global etat_create
        # history_list.addItem(url.toString())
        history.append(url.toString())
        # Création de la connexion à la base de données
        conn = sqlite3.connect('files/database.db')

        # Création d'un curseur pour exécuter des requêtes SQL
        cursor = conn.cursor()

        
        

        if "search?q" in url.toString():
            info_url = extract_search_query(url.toString(), "q")
            print(info_url)
            topic = get_search_topic(info_url, vectorizer2)
            # Ajout d'un nouvel utilisateur à la table 'users'
            cursor.execute(
            "INSERT INTO historics (username, historic, theme) VALUES (?, ?, ?)",
            (etat_create, url.toString(), topic))

            # Enregistrement des modifications dans la base de données
            conn.commit()


        elif "search_query" in url.toString():
            info_url = extract_search_query(url.toString(), "search_query")
            topic = get_search_topic(info_url, vectorizer2)
            cursor.execute(
            "INSERT INTO historics (username, historic, theme) VALUES (?, ?, ?)",
            (etat_create, url.toString(), topic))

            # Enregistrement des modifications dans la base de données
            conn.commit()

        elif "https://www.youtube.com/watch?v=" in url.toString():
            info_url, channel_name = get_video_title(url.toString())
            info_url = str(info_url)+" "+str(channel_name)
            #print("\n",info_url)
            topic = get_video_topic(info_url, vectorizer1)
            cursor.execute(
            "INSERT INTO youtube (username, theme,youtuber) VALUES (?, ?, ?)",
            (etat_create, topic, channel_name))

            # Enregistrement des modifications dans la base de données
            conn.commit()

        else:
            info_url = url.toString()

        # Fermeture de la connexion
        conn.close()
        pass

    def get_search_topic(info, vectorizer2):
        pickled_model = pickle.load(open('files/logisticregression_word_classification.pkl', 'rb'))
        x_predict = [info]
        x_predict = vectorizer2.transform(x_predict)
        y_predict = pickled_model.predict(x_predict)
        print(y_predict)
        return y_predict

    def get_video_topic(info, vectorizer1):
        pickled_model = pickle.load(open('files/logisticregression_youtube_video_classification.pkl', 'rb'))
        x_predict = [info]
        x_predict = vectorizer1.transform(x_predict)
        y_predict = pickled_model.predict(x_predict)
        print(y_predict)
        return y_predict

    def building_model_video():
        df = pd.read_csv("files/title_and_channelname.csv")
        df = df.sample(frac=1)
        title = list(map(" ".join,df[['title', 'channelTitle']].values.tolist()))
        y = df[['snippet']].to_numpy()
        vectorizer1 = TfidfVectorizer()
        x = vectorizer1.fit_transform(title)
        return vectorizer1

    def building_model_search():
        df = pd.read_csv("files/youtube_data.csv")
        df = df.sample(frac=1)
        title = list(map(" ".join,df[['title']].values.tolist()))
        y = df[['snippet']].to_numpy()
        vectorizer2 = TfidfVectorizer()
        x = vectorizer2.fit_transform(title)
        return vectorizer2

    # API Youtube for getting topic
    api_key = "AIzaSyCZhvIQ-sqRDAf4aG8Wb9Ufd-iqmGkSL44"
    history = [] #list of the url history the user visited
    topics = [] #list of the topics the user is interested in


    app = QApplication(sys.argv)

    window = QWidget()
    window.setGeometry(int((1920/2)-(535/2)), int((1030/2)-(790/2)), 535, 790)

    # Create a general VLayout
    layout = QVBoxLayout()

    # Create a tab widget
    tab_widget = QTabWidget()

    # LOAD GOOGLE
    google_view = QWebEngineView()
    google_view.load(QUrl('https://www.google.com'))
    # google_view.setZoomFactor(1)
    google_view.setStyleSheet("background-color: rgb(3, 82, 181);")

    # BACK GOOGLE
    back_button = QPushButton("Back")
    back_button.setStyleSheet("color: white; background-color: rgb(3, 82, 181);")
    back_button.clicked.connect(google_view.back)

    # DISCONNECT GOOGLE
    disconnect_button = QPushButton("Log out")
    disconnect_button.setStyleSheet("color: white; background-color: rgb(3, 82, 181);")
    disconnect_button.clicked.connect(disconnect_fct)

    # HLayout BUTTONS
    button_layout = QHBoxLayout()
    button_layout.addWidget(back_button)
    button_layout.addWidget(disconnect_button)

    # LAYOUT GOOGLE
    google_layout = QVBoxLayout()
    google_layout.addWidget(google_view)
    google_layout.addLayout(button_layout)

    # WIDGET GOOGLE
    google_widget = QWidget()
    google_widget.setLayout(google_layout)
    google_widget.setStyleSheet("background-color: rgb(3, 82, 181);")


    # LOAD YOUTUBE
    youtube_view = QWebEngineView() 
    youtube_view.load(QUrl('https://www.youtube.com'))
    youtube_view.setZoomFactor(1)
    youtube_view.setStyleSheet("background-color: rgb(3, 82, 181);")

    # BACK YOUTUBE
    back_button = QPushButton("Back")
    back_button.clicked.connect(youtube_view.back)
    back_button.setStyleSheet("color: white; background-color: rgb(3, 82, 181);")

    # DISCONNECT YOUTUBE
    disconnect_button = QPushButton("Log out")
    disconnect_button.setStyleSheet("color: white; background-color: rgb(3, 82, 181);")
    disconnect_button.clicked.connect(disconnect_fct)

    # HLayout BUTTONS
    button_layout = QHBoxLayout()
    button_layout.addWidget(back_button)
    button_layout.addWidget(disconnect_button)

    # LAYOUT YOUTUBE
    youtube_layout = QVBoxLayout()
    youtube_layout.addWidget(youtube_view)
    youtube_layout.addLayout(button_layout)

    # WIDGET YOUTUBE
    youtube_widget = QWidget()
    youtube_widget.setLayout(youtube_layout)
    youtube_widget.setStyleSheet("background-color: rgb(3, 82, 181);")

    # ADD WIDGETS TO TABS
    tab_widget.addTab(google_widget, 'Google')
    tab_widget.addTab(youtube_widget, 'Youtube')
    tab_widget.setStyleSheet("color: rgb(3, 82, 181); font-size: 15pt")

    # WIDGET HISTORY
    history_list = QListWidget()
    history_list.setStyleSheet("border-radius:2px;")

    # UPDATE HISTORY WHEN URL CHANGE
    google_view.urlChanged.connect(lambda url: update_history(url, history_list))
    youtube_view.urlChanged.connect(lambda url: update_history(url, history_list))

    # ADD TABS TO GENERAL VLayout
    layout.addWidget(tab_widget)
    # layout.addWidget(history_list)  #not visible for user


    


    # SET GENERAL VLayout TO APP
    window.setLayout(layout)
    window.setStyleSheet("background-color: rgb(3, 82, 181);")
    window.show()
    vectorizer1 = building_model_video()
    vectorizer2 = building_model_search()

    # RUN
    app.exec_()

  
  

  
def create_window():
    #from comparaison_chaine import *
    def id_window(nom_test,prenom_test,age_test):
      sys.setrecursionlimit(10000)

      pytesseract.pytesseract.tesseract_cmd = 'Lib/site-packages/pytesseract/tesseract/tesseract'

      # Utilisation de la caméra
      webcam = cv.VideoCapture(0)
      #print("ok",webcam.isOpened())

      # Reconnaissance faciale dans la vidéo
      dirCascadeFiles = r'../opencv_files/'
      # Get files from openCV : https://github.com/opencv/opencv/tree/3.4/data/haarcascades
      classCascadefacial = cv.CascadeClassifier("opencv_files/haarcascade_frontalface_default.xml")
      classCascadeSmile = cv.CascadeClassifier("opencv_files/haarcascade_profileface.xml")

      marge = 5
      point_droit = 50
      point_gauche = 575
      point_haut = 30
      point_bas = 405
      marge_droite = 380
      marge_gauche = 5
      marge_haute = 95
      marge_basse = 135
      filename = "Photo_test_"
      typ = ".jpg"
      indice = 1
      global nom
      global prenom
      global date_
      nom = ""
      prenom = ""
      date_ = ""

      # Niveaux de gris
      def grayscale(image):
          return cv.cvtColor(image, cv.COLOR_BGR2GRAY)
      # Réduction de bruits
      def remove_noise(image):
          return cv.medianBlur(image,1)
      # Seuillage
      def thresholding(image):
          return cv.threshold(image, 200, 255, cv.THRESH_OTSU)[1]

      def facialDetectionAndMark(_image, _classCascade):
          imgreturn = _image.copy()
          #imgreturn = cv.flip(imgreturn,1)
          cv.rectangle(imgreturn,(point_gauche,point_haut),(point_droit,point_bas),(255, 0, 0),2)
          result = False
          capture = imgreturn
          color = cv.cvtColor(imgreturn, cv.COLOR_BGR2RGB)
          faces = _classCascade.detectMultiScale(
              color,
              scaleFactor=1.1,
              minNeighbors=5,
              minSize=(30, 30),
              flags = cv.CASCADE_SCALE_IMAGE
          )
          try :
              x = faces[0][0]
              y = faces[0][1]
              w = faces[0][2]
              h = faces[0][3]
              result = True
              #print(x,y,w,h)
          except:
              return color,capture, result

          
          #cv.rectangle(color, (x-marge, y-marge), (x+w+marge, y+h+marge), (0, 255, 0), 2)
          x1 = 165
          y1 = 70
          w1 = 350
          h1 = 105
          y2 = 105
          h2 = 150
          y3 = 150
          h3 = 180
          x3 = 320
          w3 = 500
          
          
          capture = imgreturn[point_haut:point_bas, point_droit:point_gauche]
          capture = cv.flip(capture,1)
          #capture = cv.flip(capture,1)
          #cv.rectangle(capture, (x1, y1), (w1, h1), (0, 255, 0), 2)
          #cv.rectangle(capture, (x1, y2), (w1, h2), (0, 255, 0), 2)
          #cv.rectangle(capture, (x3, y3), (w3, h3), (0, 255, 0), 2)
          #capture = cv.cvtColor(capture, cv.COLOR_BGR2GRAY)
          return color,capture,result


      def show_frames():
          x1 = 90
          y1 = 300
          w1 = 555
          h1 = 350
          x2 = 90
          w2 = 555
          y2 = 350
          h2 = 400
          y3 = 180
          h3 = 225
          x3 = 370
          w3 = 550
          global flag
          global timer_start
          global timer_start_appli
          global nom
          global prenom
          global date_
          
          bImgReady, imageframe = webcam.read() # get frame per frame from the webcam
          cv.rectangle(imageframe, (x1, y1), (w1, h1), (0, 255, 0), 2)
          cv.rectangle(imageframe, (x2, y2), (w2, h2), (0, 255, 0), 2)
          cv.rectangle(imageframe, (x3, y3), (w3, h3), (0, 255, 0), 2)
          imageframe = cv.flip(imageframe,1)
          color = cv.cvtColor(imageframe, cv.COLOR_BGR2RGB)
          
          if bImgReady:
              face,capture,result = facialDetectionAndMark(imageframe, classCascadefacial)
              if result == True and flag == 0 :
                  flag = 1
                  timer_start = time.time()+7
                  timer_start_appli = time.time()+60
                  label['text'] =("Capture dans 4 secondes")
              elif flag == 1 :
                  if timer_start-time.time() <= 4 and timer_start-time.time() > 3:
                      label['text'] =("Capture dans 3 secondes")
                  elif timer_start-time.time() <= 3 and timer_start-time.time() > 2:
                      label['text'] =("Capture dans 2 secondes")
                  elif timer_start-time.time() <= 2 and timer_start-time.time() > 1:
                      label['text'] =("Capture dans 1 seconde")
                  elif timer_start-time.time() <= 1 and timer_start-time.time() > 0:
                      label['text'] =("Capture maintenant")
                  elif timer_start-time.time() <= 0:
                      label['text'] =("Capture maintenant")
                      flag = 2
              if result == True and flag == 2 :
                  if timer_start_appli - time.time() <=0 :
                      win.destroy()
                      return nom,prenom, date_
                  x1 = 0
                  y1 = 300 - point_haut
                  w1 = 525
                  h1 = 350- point_haut
                  x2 = 0
                  w2 = 525
                  y2 = 350- point_haut
                  h2 = 400- point_haut
                  y3 = 180- point_haut
                  h3 = 225- point_haut
                  x3 = 370 - point_droit
                  w3 = 550 - point_droit   
                          
                          
                  finalimage = remove_noise(grayscale(capture))
                  region_Nom = finalimage[y1:h1, x1:w1]
                  region_Prenom = finalimage[y2:h2, x1:w1]
                  region_date = finalimage[y3:h3, x3:w3]
                  
                  #d = pytesseract.image_to_string(region_Nom)
                  #print("Le nom est : ",d)
                  #d2 = pytesseract.image_to_string(region_Prenom)
                  #print("Le prénom est : ",d2)
                  #d3 = pytesseract.image_to_string(region_date)
                  #print("La date de naissance est : ",d3)
                  cv.imwrite("files/nom.jpg",region_Nom)
                  cv.imwrite("files/date.jpg",region_date)
                  cv.imwrite("files/prenom.jpg",region_Prenom)

                  nom_inter,prenom_inter,date_inter = recup_data()
                  #print("nom : ",nom)
                  #print("prenom : ",prenom)
                  #print("date : ",date_)
                  if nom == "":
                      nom = nom_inter
                  if prenom == "":
                      prenom = prenom_inter
                  if date_ == "":
                      date_ = date_inter
                  if date_ == "" or prenom == "" or nom == "":
                      flag = 1
                      timer_start = time.time()+3
                      img = Image.fromarray(face)
                      imgtk = ImageTk.PhotoImage(image = img)

                      canvas.create_image(0, 0, image=imgtk, anchor=NW)

                      # Met à jour l'objet PhotoImage afin qu'il ne soit pas garbage collected
                      canvas.image = imgtk
                      label.imgtk = imgtk
                      win.after(3,show_frames)
                  elif date_ != "" or prenom != "" or nom != "":
                      #print(nom)
                      #print(prenom)
                      #print(date_)
                      win.destroy()
              else :
                  img = Image.fromarray(face)
                  imgtk = ImageTk.PhotoImage(image = img)
                  canvas.create_image(0, 0, image=imgtk, anchor=NW)

                  # Met à jour l'objet PhotoImage afin qu'il ne soit pas garbage collected
                  canvas.image = imgtk
                  label.imgtk = imgtk
                  win.after(3,show_frames)
                  
              win.mainloop()
              
              
          else:
              print('No image available')
          keystroke = cv.waitKey(20) # Wait for Key press

          return nom,prenom,date_
              


      def comp_str(str1,str2):
          #print(str1,str2)
          pourcentage_limit = 0.75
          size_1 = len(str1)
          size_2 = len(str2)

          taille_max = max(size_1,size_2)
          compteur = 0

          if taille_max == size_1:
              chaine_sup = str1
              chaine_inf = str2
              taille = size_2
          else:
              chaine_sup = str2
              chaine_inf = str1
              taille = size_1

          if chaine_inf in chaine_sup :
              return True

          for i in range(taille):
              if chaine_inf[i] in chaine_sup:
                  compteur +=1

          pourcentage = compteur / taille_max
          #print(pourcentage)

          if pourcentage < pourcentage_limit:
              return False
          else:
              return True
              

      def comp_age(str_date,age_renseigné):

          # traitement de la date d'anniversaire
          if str_date[0] != '0' and str_date[0]!= '1' and str_date[0]!= '2' and str_date[0]!= '3':
            jour = int("0" + str_date[1])
          else:
            jour = int(str_date[0:2])
          if str_date[2] != '0' and str_date[2] !='1':
            mois = int("0"+ str_date[3])
          else:
            mois = int(str_date[2:4])
          year = int(str_date[4:8])
          birthDate = date(year, mois, jour)

          # date actuelle
          today = date.today()

          #calcul de l'age 
          try :
              age = today.year - birthDate.year -((today.month, today.day) <(birthDate.month, birthDate.day))
          except:
              return False

          #comparaison par rapport à l'age renseigné
          
          if age == int(age_renseigné):
              return True
          else:
              return False

      def recup_data():
          img_nom = cv.imread('files/nom.jpg')
          img_prenom = cv.imread('files/prenom.jpg')
          img_date = cv.imread('files/date.jpg')

          # Adding custom options
          nom = pytesseract.image_to_string(img_nom)
          prenom = pytesseract.image_to_string(img_prenom)
          date = pytesseract.image_to_string(img_date)

          return nom,prenom,date

      def check(nom,prenom,date):
          print(nom)
          nom = nom[5:]
          print(nom)
          nom_2, prenom_2, date_2 = "", "", ""
          for i in nom:
              if i == " ":
                  nom_2 = ""
              else:
                  if i.isdigit():
                      pass
                  elif i.isupper():
                      nom_2+=i
                  elif i == "<":
                      break
              #print(nom_2)
          
          nom_3 = nom_2
          if "RA" in nom_2:
              for i in range(len(nom_2)):
                  if nom_2[i] == "A" and nom_2[i-1] == "R":
                      nom_3 = nom_2[i+1:]
          
          #print("n:",nom_2)
          for i in date:
              if i.isdigit():
                  date_2 += i
              else:
                  continue

          for i in prenom:
              if i == " ":
                  prenom_2 = ""
              else:
                  if i.isdigit():
                      pass
                  elif i.isupper():
                      prenom_2 +=i
                  elif i == "<":
                      break     
          
          # date_2 = date_2[0:2]+'.'+date_2[2:4]+'.'+date_2[4:8]
          
          return nom_3,prenom_2,date_2
              

      def videoDetection():
          
          nom,prenom,date = "","",""
          
          if webcam.isOpened():
              #print("ok2")
              global flag
              flag = 0
              nom,prenom,date = show_frames()  
              
              webcam.release()
              cv.destroyAllWindows()
              print("Nom :", nom)
              nom,prenom,date = check(nom,prenom,date)
              print("Nom :", nom)
              print("Prenom :", prenom)
              print("Date :", date)
              result_age = False
              result_prenom = False
              result_nom = False
              if nom != "" and prenom != "" and date != "":
                  
                  result_nom = comp_str(nom,nom_test.upper())
                  result_prenom = comp_str(prenom,prenom_test.upper())
                  result_age= comp_age(date,age_test)

                  print(result_nom)
                  print(result_prenom)
                  print(result_age)
              
              if result_age == True and result_nom == True and result_prenom == True:
                  return True
              else: 
                  return False
          else:
              return False
          
              
              
      def fermer():
          win.destroy()


      win = Tk()
      win.configure(bg= "#0352b5")
      win.title("Affichage de la caméra")

      label_expli = Label(win,text=" ")
      label_expli.configure(bg= "#0352b5",font=("MS Gothic;", 18), fg ="white")
      label_expli.pack()

      label_title = Label(win,text=" Veuillez présenter votre carte d'identité en la plaçant dans le carde bleu !")
      label_title.configure(bg= "#0352b5",font=("MS Gothic;", 18), fg ="white")
      label_title.pack()

      label_expli2 = Label(win,text=" ")
      label_expli2.configure(bg= "#0352b5",font=("MS Gothic;", 18), fg ="white")
      label_expli2.pack()

      # Crée un label pour afficher le compte à rebours
      label = Label(win, text="Capture dans 5 secondes")

      label.configure(bg= "#0352b5",font=("MS Gothic;", 18), fg ="white")
      label.pack()

      # Crée un canvas pour afficher l'image
      canvas = Canvas(win, width=640, height=480)
      canvas.configure(bg= "#0352b5")
      canvas.pack()

      reponse = videoDetection()
      return reponse

    

    global etat_utilisateur
    global etat_create
    # Fonction pour vérifier si un nom d'utilisateur est déjà utilisé
    def check_username(username):
        # Connexion à la base de données
        conn = sqlite3.connect('files/database.db')
        c = conn.cursor()

        # Exécution de la requête SQL pour vérifier si le nom d'utilisateur existe déjà dans la table
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        result = c.fetchone()

        # Fermeture de la connexion à la base de données
        conn.close()

        # Si aucun enregistrement n'a été trouvé, le nom d'utilisateur est disponible
        if result is None:
            return True
        # Sinon, le nom d'utilisateur est déjà utilisé
        else:
            return False

    # Fonction pour vérifier si un âge est valide (entier compris entre 1 et 150)
    def check_age(age):
        try:
            age = int(age)
            return 13 <= age <= 150
        except ValueError:
            return False

    # Fonction pour créer un nouveau compte
    def create_account():
        global etat_create
        global etat_utilisateur
        # Récupération des données du formulaire
        username = username_entry.text()
        first_name = (first_name_entry.text()).upper()
        last_name = (last_name_entry.text()).upper()
        age = age_entry.text()
        password = password_entry.text()

        

        # Vérification de la disponibilité du nom d'utilisateur et de la validité de l'âge
        if check_username(username) and check_age(age):
            result = False
            try:
              result = id_window(last_name,first_name,age) 
            except:
              print("Erreur Carte d'identité")
            if result:

              # Création de la connexion à la base de données
              conn = sqlite3.connect('files/database.db')

              # Création d'un curseur pour exécuter des requêtes SQL
              cursor = conn.cursor()

              # Ajout d'un nouvel utilisateur à la table 'users'
              cursor.execute(
                  "INSERT INTO users (username, first_name, last_name, age, password,confiance) VALUES (?, ?, ?, ?, ?, ?)",
                  (username, first_name, last_name, int(age), password, int(50))
              )

              # Enregistrement des modifications dans la base de données
              conn.commit()

              # Fermeture de la connexion
              conn.close()

              # Affichage du nom d'utilisateur
              print(f"Le compte {username} a été créé avec succès !")

              # Remise à zéro du formulaire
              username_entry.clear()
              first_name_entry.clear()
              last_name_entry.clear()
              age_entry.clear()
              password_entry.clear()
              etat_create = username
              etat_utilisateur = 4
              window3.close()
              
            else:
              # Affichage d'un message d'erreur
              #etat_utilisateur = 5
              #window3.close()
              print("Erreur avec la carte d'identité")
        else:
            etat_utilisateur = 5
            window3.close()
            # Affichage d'un message d'erreur
            print("Le nom d'utilisateur est déjà utilisé ou l'âge n'est pas valide")

    def quitte():
      global etat_utilisateur
      window3.close()
      etat_utilisateur = 1

    # Création de la fenêtre principale
    app3 = QApplication(sys.argv)

    window3 = QWidget()
    #screen_geometry = app.desktop().availableGeometry()
    window3.setGeometry(int((1920/2)-(535/2)), int((1030/2)-(790/2)), 535, 790)
    window3.setStyleSheet("background-color: rgb(3, 82, 181);")

    # Création du formulaire
    image_label = QLabel()
    image_label.setPixmap(QPixmap('images/logo_QYL_account.png'))


    title_label = QLabel("   Création d'un utilisateur")
    title_label.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
    empty_label = QLabel("  ")
    empty_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    empty2_label = QLabel("  ")
    empty2_label.setStyleSheet("font-family: MS Gothic;font-size: 14pt; color: white;")
    username_label = QLabel("Nom d'utilisateur :")
    username_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    username_entry = QLineEdit()
    username_entry.setStyleSheet("font-size: 21pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    first_name_label = QLabel("Prénom :")
    first_name_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    first_name_entry = QLineEdit()
    first_name_entry.setStyleSheet("font-size: 21pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    last_name_label = QLabel("Nom de famille :")
    last_name_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    last_name_entry = QLineEdit()
    last_name_entry.setStyleSheet("font-size: 21pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    age_label = QLabel("Âge :")
    age_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    age_entry = QLineEdit()
    age_entry.setStyleSheet("font-size: 21pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    password_label = QLabel("Mot de passe :")
    password_label.setStyleSheet("font-family: MS Gothic;font-size: 18pt; color: white;")
    password_entry = QLineEdit()
    password_entry.setStyleSheet("font-size: 21pt; font-family: MS Gothic; color: black;background-color: white;border-radius: 5px;")
    password_entry.setEchoMode(QLineEdit.Password)

    # Création du bouton "Créer"
    create_button = QPushButton("Créer")
    create_button.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    create_button.setFixedWidth(200)
    
    create_button.clicked.connect(create_account)

    # Création du bouton "Annuler"
    cancel_button = QPushButton("Annuler")
    cancel_button.setStyleSheet("font-size: 26pt;  color: rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    cancel_button.setFixedWidth(200)
    
    cancel_button.clicked.connect(quitte)

    # Mise en place du formulaire et du bouton "Annuler" dans la fenêtre
    Llayout = QVBoxLayout()
    layout = QHBoxLayout()
    left_layout = QVBoxLayout()
    right_layout = QVBoxLayout()


    left_layout.addWidget(empty_label)
    left_layout.addWidget(username_label)
    left_layout.addWidget(first_name_label)
    left_layout.addWidget(last_name_label)
    left_layout.addWidget(age_label)
    left_layout.addWidget(password_label)
    left_layout.addWidget(empty_label)
    left_layout.addWidget(empty2_label)
    left_layout.addWidget(cancel_button, 0, Qt.AlignHCenter)
    

    right_layout.addWidget(empty_label)
    right_layout.addWidget(username_entry)
    right_layout.addWidget(first_name_entry)
    right_layout.addWidget(last_name_entry)
    right_layout.addWidget(age_entry)
    right_layout.addWidget(password_entry)
    right_layout.addWidget(empty_label)
    right_layout.addWidget(empty2_label)
    right_layout.addWidget(create_button, 0, Qt.AlignHCenter)
    
    
    #layout.addWidget(empty_label)
    layout.addLayout(left_layout)
    layout.addLayout(right_layout)

    
    Llayout.addWidget(title_label)
    Llayout.addLayout(layout)
    Llayout.addWidget(empty_label)
    Llayout.addWidget(image_label)
    Llayout.addWidget(empty_label)
    

    window3.setLayout(Llayout)

    # Affichage de la fenêtre

    
    window3.show()

    app3.exec_()

def fenetre_statique():
    global etat_utilisateur
    def fenetre_musique():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Musique"] = "Soprano"
            eval()

        def choix2():
            dict_ci["Musique"] = "Lomepal"
            eval()

        def choix3():
            dict_ci["Musique"] = "Big Flo et Oli"
            eval()

        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Musique: Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/soprano.jpg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Soprano")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/lomepal.jpg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("Lomepal")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/bigfloetoli.jpg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("BigFlo et Oli")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)
    
    def fenetre_humour():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Humour"] = "Squeezie"
            eval()
        def choix2():
            dict_ci["Humour"] = "Paul Mirabel"
            eval()

        def choix3():
            dict_ci["Humour"] = "Booder"
            eval()

        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Humour : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/squeezie.jpg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Squeezie")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/paulmirabel.jpeg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("Paul Mirabel")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/booder.jpeg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("Booder")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)

    def fenetre_jeux_video():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Jeux vidéos"] = "Fortnite"
            eval()

        def choix2():
            dict_ci["Jeux vidéos"] = "Michou"
            eval()


        def choix3():
            dict_ci["Jeux vidéos"] = "Squeezie"
            eval()


        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Jeux Vidéo : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/fortnite.jpg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Fortnite")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/michou.jpg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("Michou")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/squeezie.jpg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("Squeezie")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)

    def fenetre_beaute():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Beauté"] = "LouFitLove"
            eval()


        def choix2():
            dict_ci["Beauté"] = "Léna Situations"
            eval()


        def choix3():
            dict_ci["Beauté"] = "Les Reines du shopping"
            eval()

        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Beauté : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/loufitlove.jpg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("LouFitLove")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/lenasituations.jpg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("Léna Situations")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/reineshop.jpg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("LRDS")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)
    
    def fenetre_sport():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Sport"] = "Tibo Inshape"
            eval()

        def choix2():
            dict_ci["Sport"] = "Foot"
            eval()


        def choix3():
            dict_ci["Sport"] = ""
            eval()


        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Sport : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/tiboinshape.jpeg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Tibo Inshape")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/football.png")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("Football")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/autre_sport.jpg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("Autre Sport")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)

        
            



    def fenetre_cinema():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Cinéma"] = "Marvel"
            eval()

        def choix2():
            dict_ci["Cinéma"] = "The Rock"
            eval()

        def choix3():
            dict_ci["Cinéma"] = "Jenna Ortega"
            eval()

        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Cinéma : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/marvel.jpeg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Marvel")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/therock.jpg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("The Rock")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/jennaortega.jpeg")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("Jenna Ortega")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)


    def fenetre_info():
        global liste_fonction
        global dict_ci
        def choix1():
            dict_ci["Informations"] = "C'est pas sorcier"
            eval()

        def choix2():
            dict_ci["Informations"] = "Hugo Décrypte"
            eval()

        def choix3():
            dict_ci["Informations"] = ""
            eval()

        for widget in window7.findChildren((QLabel, QPushButton)):
            widget.setParent(None)
            widget.deleteLater()
        label = QLabel("Catégorie Information : Faites un choix")
        label.setStyleSheet("font-size: 20pt; color: white;font-weight: bold; font-style: italic;")
        label_ph = QLabel("Choississez une personnalité")
        label_ph.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
        empty_label = QLabel(" ")

        #layout_sport = QVBoxLayout()

        button_sport1 = QPushButton()
        button_sport1.setFixedHeight(230)
        button_sport1.setFixedWidth(300)
        image_sport1 = QLabel()
        pixmap_sport1 = QPixmap("images/cestpassorcier.jpg")
        image_sport1.setPixmap(pixmap_sport1)

        # Create the label
        label_sport1 = QLabel("Jamy")
        label_sport1.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport1 = QVBoxLayout()
        layout_sport1.addWidget(image_sport1, 0, Qt.AlignHCenter)
        layout_sport1.addWidget(label_sport1, 0, Qt.AlignHCenter)

        button_sport2 = QPushButton()
        button_sport2.setFixedHeight(230)
        button_sport2.setFixedWidth(300)
        image_sport2 = QLabel()
        pixmap_sport2 = QPixmap("images/hugodecrypte.jpg")
        image_sport2.setPixmap(pixmap_sport2)

        # Create the label
        label_sport2 = QLabel("HugoDécrypte")
        label_sport2.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport2 = QVBoxLayout()
        layout_sport2.addWidget(image_sport2, 0, Qt.AlignHCenter)
        layout_sport2.addWidget(label_sport2, 0, Qt.AlignHCenter)

        button_sport3 = QPushButton()
        button_sport3.setFixedHeight(230)
        button_sport3.setFixedWidth(300)
        image_sport3 = QLabel()
        pixmap_sport3 = QPixmap("images/news.png")
        image_sport3.setPixmap(pixmap_sport3)

        # Create the label
        label_sport3 = QLabel("Informations")
        label_sport3.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")

        # Create the layout
        layout_sport3 = QVBoxLayout()
        layout_sport3.addWidget(image_sport3, 0, Qt.AlignHCenter)
        layout_sport3.addWidget(label_sport3, 0, Qt.AlignHCenter)

        button_sport1.setLayout(layout_sport1)
        button_sport1.clicked.connect(choix1)
        button_sport2.setLayout(layout_sport2)
        button_sport2.clicked.connect(choix2)
        button_sport3.setLayout(layout_sport3)
        button_sport3.clicked.connect(choix3)

        layout.addWidget(label, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport1, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport2, 0, Qt.AlignHCenter)
        layout.addWidget(button_sport3, 0, Qt.AlignHCenter)


    def activate1():
        checkbox1.setChecked(not checkbox1.isChecked())
    def activate2():
        checkbox2.setChecked(not checkbox2.isChecked())
    def activate3():
        checkbox3.setChecked(not checkbox3.isChecked())
    def activate4():
        checkbox4.setChecked(not checkbox4.isChecked())
    def activate5():
        checkbox5.setChecked(not checkbox5.isChecked())
    def activate6():
        checkbox6.setChecked(not checkbox6.isChecked())
    def activate7():
        checkbox7.setChecked(not checkbox7.isChecked())

    def eval():
        global liste_fonction
        global etat_utilisateur
        if len(liste_fonction) != 0:
            if liste_fonction[0] == "fenetre_sport()":
                fenetre_sport()
            elif liste_fonction[0] == "fenetre_musique()":
                fenetre_musique()
            elif liste_fonction[0] == "fenetre_humour()":
                fenetre_humour()
            elif liste_fonction[0] == "fenetre_jeux_video()":
                fenetre_jeux_video()
            elif liste_fonction[0] == "fenetre_beaute()":
                fenetre_beaute()
            elif liste_fonction[0] == "fenetre_cinema()":
                fenetre_cinema()
            else:
                fenetre_info()
            liste_fonction.pop(0)
        else:
                window7.close()
                etat_utilisateur = 1


    def execute_fonction():
        global liste_fonction 
        if checkbox1.isChecked():
            liste_fonction.append("fenetre_sport()")
        if checkbox2.isChecked():
            liste_fonction.append("fenetre_musique()")
        if checkbox3.isChecked():
            liste_fonction.append("fenetre_humour()")
        if checkbox4.isChecked():
            liste_fonction.append("fenetre_jeux_video()")
        if checkbox5.isChecked():
            liste_fonction.append("fenetre_beaute()")
        if checkbox6.isChecked():
            liste_fonction.append("fenetre_cinema()")
        if checkbox7.isChecked():
            liste_fonction.append("fenetre_info()")
        if len(liste_fonction) != 0:
            eval()
        
        


        
    global liste_fonction
    global dict_ci
    liste_fonction = []
    dict_ci = {"Sport": "","Musique":"","Humour":"","Jeux vidéos":"","Beauté":"","Cinéma":"","Informations":""}
    app5 = QApplication(sys.argv)

    window7 = QWidget()
    window7.setWindowTitle("Centre d'intérêts")
    window7.setGeometry(int((1920/2)-(535/2)), int((1030/2)-(790/2)), 535, 790)
    window7.setStyleSheet("background-color: rgb(3, 82, 181);")

    label = QLabel("Choisissez vos centres d'intérêts")
    label.setStyleSheet("font-size: 26pt; color: white;font-weight: bold; font-style: italic;")
    empty_label = QLabel(" ")
    #empty_label.setStyleSheet("font-size: 5pt; color: white;font-weight: bold; font-style: italic;")



    label1 = QLabel(" Sport")
    label1.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon1 = QIcon("images\sport.png")
    labelicon1 = QLabel()
    labelicon1.setPixmap(icon1.pixmap(32, 32))

    checkbox1 = QCheckBox()

    layout1 = QHBoxLayout()
    layout1.addWidget(checkbox1)
    layout1.addWidget(labelicon1)
    layout1.addWidget(label1)
    layout1.setAlignment(Qt.AlignCenter)



    button1 = QPushButton()
    button1.setLayout(layout1)
    button1.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button1.setFixedWidth(350)
    button1.setFixedHeight(60)
    button1.clicked.connect(activate1)


    label2 = QLabel(" Musique")
    label2.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon2 = QIcon("images/musique.png")
    labelicon2 = QLabel()
    labelicon2.setPixmap(icon2.pixmap(32, 32))

    checkbox2 = QCheckBox()

    layout2 = QHBoxLayout()
    layout2.addWidget(checkbox2)
    layout2.addWidget(labelicon2)
    layout2.addWidget(label2)
    layout2.setAlignment(Qt.AlignCenter)

    button2 = QPushButton()
    button2.setLayout(layout2)
    button2.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button2.setFixedWidth(350)
    button2.setFixedHeight(60)
    button2.clicked.connect(activate2)


    label3 = QLabel(" Humour")
    label3.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon3 = QIcon("images/humour.png")
    labelicon3 = QLabel()
    labelicon3.setPixmap(icon3.pixmap(32, 32))

    checkbox3 = QCheckBox()

    layout3 = QHBoxLayout()
    layout3.addWidget(checkbox3)
    layout3.addWidget(labelicon3)
    layout3.addWidget(label3)
    layout3.setAlignment(Qt.AlignCenter)

    button3 = QPushButton()
    button3.setLayout(layout3)
    button3.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button3.setFixedWidth(350)
    button3.setFixedHeight(60)
    button3.clicked.connect(activate3)

    label4= QLabel(" Jeux Vidéos")
    label4.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon4 = QIcon("images/jeux_video.png")
    labelicon4 = QLabel()
    labelicon4.setPixmap(icon4.pixmap(32, 32))

    checkbox4 = QCheckBox()

    layout4 = QHBoxLayout()
    layout4.addWidget(checkbox4)
    layout4.addWidget(labelicon4)
    layout4.addWidget(label4)
    layout4.setAlignment(Qt.AlignCenter)

    button4 = QPushButton()
    button4.setLayout(layout4)
    button4.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button4.setFixedWidth(350)
    button4.setFixedHeight(60)
    button4.clicked.connect(activate4)


    label5 = QLabel(" Beauté")
    label5.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon5 = QIcon("images/beaute.png")
    labelicon5 = QLabel()
    labelicon5.setPixmap(icon5.pixmap(32, 32))

    checkbox5 = QCheckBox()

    layout5 = QHBoxLayout()
    layout5.addWidget(checkbox5)
    layout5.addWidget(labelicon5)
    layout5.addWidget(label5)
    layout5.setAlignment(Qt.AlignCenter)

    button5 = QPushButton()
    button5.setLayout(layout5)
    button5.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button5.setFixedWidth(350)
    button5.setFixedHeight(60)
    button5.clicked.connect(activate5)

    label6 = QLabel(" Cinéma")
    label6.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon6 = QIcon("images/cinéma.png")
    labelicon6 = QLabel()
    labelicon6.setPixmap(icon6.pixmap(32, 32))

    checkbox6 = QCheckBox()

    layout6 = QHBoxLayout()
    layout6.addWidget(checkbox6)
    layout6.addWidget(labelicon6)
    layout6.addWidget(label6)
    layout6.setAlignment(Qt.AlignCenter)

    button6 = QPushButton()
    button6.setLayout(layout6)
    button6.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button6.setFixedWidth(350)
    button6.setFixedHeight(60)
    button6.clicked.connect(activate6)


    label7 = QLabel(" Informations")
    label7.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")

    icon7 = QIcon("images/info.png")
    labelicon7 = QLabel()
    labelicon7.setPixmap(icon7.pixmap(32, 32))

    checkbox7 = QCheckBox()

    layout7 = QHBoxLayout()
    layout7.addWidget(checkbox7)
    layout7.addWidget(labelicon7)
    layout7.addWidget(label7)
    layout7.setAlignment(Qt.AlignCenter)

    button7 = QPushButton()
    button7.setLayout(layout7)
    button7.setStyleSheet("font-size: 26pt;  color:rgb(3, 82, 181);background-color: white;border-radius: 5px;")
    button7.setFixedWidth(350)
    button7.setFixedHeight(60)
    button7.clicked.connect(activate7)

    button_final = QPushButton(" Valider ")
    button_final.setStyleSheet("font-size: 30pt;  color:white;background-color: rgb(0, 180, 0);border-radius: 5px;")
    button_final.setFixedWidth(250)
    button_final.setFixedHeight(60)
    button_final.clicked.connect(execute_fonction)

    layout = QVBoxLayout()

    layout.addWidget(empty_label)
    layout.addWidget(empty_label)
    layout.addWidget(label)
    layout.addWidget(empty_label)

    layout.addWidget(empty_label)
    layout.addWidget(button1, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button2, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button3, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button4, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button5, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button6, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(button7, 0, Qt.AlignHCenter)
    layout.addWidget(empty_label)
    layout.addWidget(empty_label)
    layout.addWidget(button_final, 0, Qt.AlignHCenter)

    layout.addWidget(empty_label)

    window7.setLayout(layout)
    window7.show()

    app5.exec_()


    return dict_ci

def analyse_CI(dict):
    global etat_create
    global etat_utilisateur
    print(dict)
    # Load variable from a file
    with open('files/variable_model.pkl', 'rb') as file:
        data_a_predire = pickle.load(file)

    with open('files/trained_model2.pkl', 'rb') as file:
        model = pickle.load(file)
    
    index = data_a_predire.index
    print(index)
    i=1
    while i < len(index):
        data_a_predire = data_a_predire.drop(index[i])
        i=i+1
        
    data_a_predire[data_a_predire > 0] = 0

    X = ["['"+dict['Musique']+"']","['"+dict['Humour']+"']","['"+dict['Jeux vidéos']+"']","['"+dict['Cinéma']+"']","['"+dict['Beauté']+"']","['"+dict['Sport']+"']","['"+dict['Informations']+"']"]



    Musique = X[0]
    if data_a_predire.get(Musique) is not None:
        data_a_predire[Musique] = 1
    Humour = X[1]
    if data_a_predire.get(Humour) is not None:
        data_a_predire[Humour] = 1
    JeuxVideo = X[2]
    if data_a_predire.get(JeuxVideo) is not None:
        data_a_predire[JeuxVideo] = 1
    Art = X[3]
    if data_a_predire.get(Art) is not None:
        data_a_predire[Art] = 1
    Beauté = [4]
    if data_a_predire.get(Beauté) is not None:
        data_a_predire[Beauté] = 1
    Sport = [5]
    if data_a_predire.get(Sport) is not None:
        data_a_predire[Sport] = 1
    Info = X[6]
    if data_a_predire.get(Info) is not None:
        data_a_predire[Info] = 1

    prediction = model.predict(data_a_predire)
    
    print(np.argmax(prediction))
    result = (np.argmax(prediction) > 12)
    
    # Connexion à la base de données
    conn = sqlite3.connect('files/database.db')
    c = conn.cursor()

    if result>13:
        print(etat_create)
        # Exécution de la requête SQL pour vérifier si le nom d'utilisateur existe déjà dans la table
        c.execute("UPDATE users SET confiance = ? WHERE username = ?", (int(75), etat_create))
        conn.commit()
        
    else:
        # Exécution de la requête SQL pour vérifier si le nom d'utilisateur existe déjà dans la table
        c.execute("UPDATE users SET confiance = ? WHERE username = ?", (int(45), etat_create))
        conn.commit()
        etat_utilisateur = 5
    # Fermeture de la connexion à la base de données
    conn.close() 

def warning_screen():
    global etat_utilisateur
    global etat_create
    etat_create = ""
    etat_utilisateur = 1
    app = QApplication(sys.argv)

    # Create a main window
    window = QWidget()

    # Create a label for the image
    image_label = QLabel()
    pixmap = QPixmap("images/warning.png")
    image_label.setPixmap(pixmap)
    image_label.setStyleSheet("font-size: 25pt; color: white; background-color: #2A3C4E;font-weight: bold;")

    # Create a button
    button = QPushButton("Je comprends")
    button .clicked.connect(app.quit)
    button.setStyleSheet("font-size: 20pt; font-family: MS Gothic;background-color: white;border-radius: 5px; color:#2A3C4E;")
    button.setFixedWidth(280)

    # Create a layout for the text and image
    v_layout = QVBoxLayout()
    v_layout.addWidget(image_label)

    # Create a layout for the button
    h_layout = QHBoxLayout()
    h_layout.addStretch()
    h_layout.addWidget(button)

    # Create a final layout
    main_layout = QVBoxLayout()
    main_layout.addLayout(v_layout)
    main_layout.addLayout(h_layout)

    # Set the main layout
    window.setLayout(main_layout)
    window.setStyleSheet("font-size: 25pt; color: white; background-color: #2A3C4E;font-weight: bold;")

    # Show the main window
    window.show()

    app.exec_()

global etat_utilisateur
global etat_create
etat_create = ""
etat_utilisateur = 1


while etat_utilisateur != 0:
  if etat_utilisateur == 1:
    etat_utilisateur = 0
    connexion_window()
  elif etat_utilisateur == 3 :
    etat_utilisateur = 0
    user_window()
  elif etat_utilisateur == 2:
    etat_utilisateur = 0
    create_window()
  elif etat_utilisateur == 4:
    etat_utilisateur = 0
    CI = fenetre_statique()
    analyse_CI(CI)
  elif etat_utilisateur == 5:
    etat_utilisateur = 0
    warning_screen()
    


    





















